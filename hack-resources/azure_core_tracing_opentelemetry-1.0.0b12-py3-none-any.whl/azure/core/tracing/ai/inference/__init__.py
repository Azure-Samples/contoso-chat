# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------
from ._ai_inference_instrumentor import AIInferenceInstrumentor
